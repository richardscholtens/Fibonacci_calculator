=====
Usage
=====

To use Fibonacci Calculator in a project::

    import fibonacci_calculator
