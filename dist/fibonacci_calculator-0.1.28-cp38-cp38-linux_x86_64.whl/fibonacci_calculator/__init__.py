"""Top-level package for Fibonacci Calculator."""

__author__ = """Richard Scholtens"""
__email__ = 'richardscholtens2@gmail.com'
__version__ = '0.1.28'
